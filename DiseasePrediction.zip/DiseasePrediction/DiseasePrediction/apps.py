from django.apps import AppConfig


class DiseaseappConfig(AppConfig):
    name = 'DiseaseApp'
